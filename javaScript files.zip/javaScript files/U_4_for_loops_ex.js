/*Name: Nicholas C. Hooper Webb
Date: 10/06/2024
Program Name: U_4_for_loops_ex.js
Program Description: This is a simple program meant to demonstrate the function and ability of "for loops" in JavaScript by formatting one to ask the user to imput 5 numbers, and another to print those numbers in the console.*/

//Variables________________________________________________________________________
    
        //Comment: Here I define a variable "userNum" which I will use later to have the user assign a different value to it via a prompt.
        
let userNum = 0;

//Constants________________________________________________________________________

        //Comment: Here I define an array and leave it undefined to use later in the program.

   const userNumbers = [];
   
//Main___________________________________________________________________________

console.log("Hello.\nThis is a loop test.\n\n");

        //Comment: I define two "for" loops below: 1 to have the user enter a number and store that value to the prompt, "Please enter a number", and adds the value to the array "userNumbers", and another to print out all the values in the array.

    for (var i = 0;i <= 4;i++) {
        userNum = prompt("Please enter a number: ");
        userNumbers.push(userNum);
    }
    
console.log("\n\nHere are the numbers you entered:\n\n");    
    
    for (var i = 0;i <=4;i++) {
        console.log(userNumbers[i]);
    }
