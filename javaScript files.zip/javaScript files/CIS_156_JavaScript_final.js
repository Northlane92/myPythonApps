/*Name: Nicholas C. Hooper Webb
Date: 12/10/2024
Program Name: CIS156_JavaScript_Final.js
Program Description: This program will prompt a number from the user and generate that amount of random numbers and add them to an array. The program will the give the user an option of sorting the numbers, which will use a "bubble-sort" function to sort and display the array in order from lowest to highest, or exiting the program.*/

//Variables----------------------------------------------------------------

//array for storing random numbers
let userNumbers = [];

//variable to hold the coding to make a random number
let randomNumber;

//variable for prompting how many random numbers the user wants
let howManyNum;

//variable used in the "bubble-sort" function
let move;

//variable used for grabbing a situational "yes", or "no" response
let userResponse;


//Functions------------------------------------------------------------------


//this is the exact bubble-sort function that used in the last assignment. I re-used it here

function bubbleSort(userNumbers) {

     for (var i = 0; i < (userNumbers.length-1); i++) {
        
        for (var j = 0; j < (userNumbers.length-1-i); j++) {
            
            if (userNumbers[j] > userNumbers[j + 1]) {
                
                var move = userNumbers[j]
                userNumbers[j] = userNumbers[j + 1]
                userNumbers[j + 1] = move
            }
                
        }
        
    }
    return userNumbers;
} 


//used this function to generate a random number and add it to the array "userNumbers"

function userRng() {
    
    randomNumber = Number(Math.floor(Math.random() * (100 - 1) + 1));
    userNumbers.push(randomNumber);
    return (randomNumber);
}


//this function loops the "userRNG" function the amount of times equal to the number the user entered previoiusly for how many random numbers they want to make, minus 1, to account for the extra value "0" has in the array.

function userRngPush() {

    for (var n = 0; n < howManyNum; n++) {
    
         userRng(howManyNum -1);
    }   
}


//In this function, first there's a prompt to grab the amount of numbers the user wants generated, then I run the function "userRngPush" inside this function, which will generate random numbers the amount of times the user selected and add them to the array "userNumbers".

//Next I prompt the user if they want to have the numbers sorted, and then write a couple of "if" statements depending on what they choose. If the answer is "y" the program displays the numbers sorted and loops back to the beginning of the function - if the answer is no, the program displays a message and ends the program.

function getNumbers() {
    
    howManyNum = Number(prompt("Hello, there!\n\nThis program was made to generate and sort random numbers.\nEnter any amount of numbers to generate and I will choose them between 1 and 100.\nEach time you run the program, the new numbers will be saved!\n\nHow many numbers would you like to enter? > "));

        userRngPush();
        
    userResponse = prompt("\n\nHere are all your random numbers so far:\n\n" + userNumbers + "\n\n\nWould you like me to sort these numbers?\n\nPlease answer Y or N > ").toLowerCase();

            if (userResponse == "y") {
    
                console.log("\n\nHere are your random numbers sorted:\n\n" + bubbleSort(userNumbers) + "\n\n\n");
                getNumbers();
            }

            else if (userResponse == "n") {
    
                console.log("\n\nThank you\n\nExiting the program...");
                return;
            }

}


//Main-----------------------------------------------------------------------
    
    //super long main section =)
    
 getNumbers();


/*Michael, you've been the best teacher I've ever had. Thank you so much for your passion in teaching this art; It is obvious that you care for the subject and your students immensely. I look forward to your classes in the coming semesters with freedom, fervency, and zeal! Happy Holidays and Enjoy your break!!!      -nick*/
