/*Name: Nicholas C. Hooper Webb
  Date: 10/27/2024
  Program Name: CIS156_Functions_II.js
  Program Description: This program demonstrates the further use of functions and passing and retrieving data from functions by calculating the volume or area of a rectangle based on the user imputs for the dimensions of the rectangle.*/



//Variables---------------------------------------------------------------------
    
        //Comment: I define the variables I will use in my functions as well as the variables I will use later in the program:
        
        
let measurement; //assigns inches or centimeters to strings

let rectSideOne; //variables rectSideOne - Three are used in the volume and area                 functions
let rectSideTwo; 
let rectSideThree; 

let imperialOrMetric; //aditional variable used in assigning centimeters or                         inches to strings

let userOption; //variable for a prompt containted within a function to give the                 user a menu of 1 or 2 options

let rectLength = 0; //the rest of the variables are used to perform calculations                 for volume and/or width based on the user inputs. I need to                 declare them as 0 now to do that.
let rectWidth = 0;
let rectHeight = 0;
let volume = 0;
let area = 0;


//Functions---------------------------------------------------------------------

    
        //Comment: This first function contains prompts and if statements to determine which system of measurement the user would like to use.

function impOrMetLog() {
        
        imperialOrMetric = prompt("\n\n\nWill you be using the Imperial or Metric system for measurements?\n\nEnter I for Imperial or M for Metric: ")
  
    
    if (imperialOrMetric == "I") {
        measurement = "inches"}
        
  else if (imperialOrMetric == "M") {
        measurement = "centimeters"
    }
    
    else {
        console.log("\nI'm sorry, " + "'" + imperialOrMetric + "'" + " is not an acceptable system of measurement.\nPlease re-start the program.");
        return;
    }
}

        //Comment: This function set's up an expression to calculate volume and is formatted so that I can pass values into it and retrieve them later.

function rectVolume(rectSideOne,rectSideTwo,rectSideThree) {
    
        v = (rectSideOne*rectSideTwo*rectSideThree);
        return (v)
}

        //Comment: This function is similar to the one above, and is formatted the same, only this time the expression is to calculate the area of the rectangle.

function rectArea(rectSideOne,rectSideTwo) {
    
    a = (rectSideOne*rectSideTwo)
    return (a)
}

        //Comment: The final function creates a sort of "menu" for the user to choose from depending on whether they need the area of the volume based on the values they entered. The function will calculate and display either the volume or area.

function option() {
    
    userOption = prompt("Please select from the following options:\n\n1.Calculate the volume of the rectangular prism\n2.Calculate the area of the rectangle\n\n:");
    
    if (userOption == 1 & rectLength > 0 & rectWidth > 0 & rectHeight > 0) {
        
        volume = rectVolume(rectLength,rectWidth,rectHeight);
        
        console.log("\n\nThe volume of your rectangular prism is " + volume.toFixed(2) + " cubic " + measurement +".")
    }
    
    
    if (userOption == 2 & rectLength > 0 & rectWidth > 0) {
        
        area = rectArea(rectLength,rectWidth);
        
        console.log("\n\nThe area of your rectangle is " + area.toFixed(2) + " squared " + measurement + ".")
}
}


//Main--------------------------------------------------------------------------


        console.log("Hello.\n\nThis program was made to help you calculate the area of a\nrectangle, and/or the volume of a rectangular prism.\n\n");
        console.log("-------------------------------------------------------------------------------------");

    //Comment: First I run the "impOrMetLog" function to determine what system of measurement the user would like to use.

impOrMetLog();

console.log("\n\n-------------------------------------------------------------------------------------");

    //Comment: Next I run an if statement to make sure that if the user entered an acceptable unit of measurement the way the program told them to, than the program will proceed to ask for the values of the length, width, and height of the rectangle. If the user enters an unacceptable value, the program will end with a message to re-start it. Finally, I run the "option" function to give the user a menu and print their desired output.

if (measurement == "inches" || measurement == "centimeters") {
    
rectLength = (Number(prompt("\n\nPlease enter the length of your rectangle in " + measurement+ ": ")));

rectWidth = (Number(prompt("\nPlease enter the width of your rectangle in " + measurement+ ": ")));

rectHeight = (Number(prompt("\nPlease enter the height of your rectangle in " + measurement+ ": ")));

console.log("\n\n-------------------------------------------------------------------------------------")

option();
}