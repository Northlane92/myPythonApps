/*Name: Nicholas C. Hooper Webb
Date: 12/01/2024
Program Name: bubble_sort_demo.js
Program Description: This program is meant to demonstate the implementation of a simple "bubble sorting" functon by allowing the user to enter an array of random numbers, and then sorting them.*/

//Variables----------------------------------------------------------------
    //Here I define a number of variables I will use for the program including the array named "userNumbers" which I will fill with the user's inputs.
    
var userNumbers = [];
var numEntry;
var howManyNum;
var move;
var n;
var i;
var j;

//Main-----------------------------------------------------------------------
    
    //First I define a prompt to address how many values the user would like to enter, and then I create a for loop to display the text, "Enter Number ()" which will display a different # entry for the user depending on how many values they wanted to enter.
    
var howManyNum = Number(prompt("Hello, there!\n\nThis program was made to enter and sort random numbers.\n(Please only use numbers as entries, or the program will not work)\n\nHow many numbers would you like to enter? > "));

for (var n = 0; n < howManyNum; n++) {
    
     var numEntry = Number(prompt("\n\nEnter number " + (n + 1) + ": "));
     
     userNumbers.push(numEntry);
     
}   

    //Second I create a function named "bubbleSort" with (userNumbers) and nest the necessary code to run the bubble sorting feature. 
    
function bubbleSort(userNumbers) {

     for (var i = 0; i < (userNumbers.length-1); i++) {
        
        for (var j = 0; j < (userNumbers.length-1-i); j++) {
            
            if (userNumbers[j] > userNumbers[j + 1]) {
                
                var move = userNumbers[j]
                userNumbers[j] = userNumbers[j + 1]
                userNumbers[j + 1] = move
            }
                
        }
        
    }
    return userNumbers;
}    

        //Finally I create a couple messages that will display what the user entered to be sorted, and the final result of the bubble sort.

     console.log ("\n\nHere are the numbers you would like to sort:\n" + (userNumbers) + "\n\n");
     
    console.log ("Here is the sorted array of the numbers you entered:\n" + (bubbleSort(userNumbers)));
     
