/* Name: Nicholas C. Hooper Webb
   Date: 09/29/2024
   Program name: CIS 156 Project 2
   Program Description: This program asks the user to imput a first and then second set of values consisting of an adjective, a noun that is an idea, and a noun that is an object. The program will then separate and add the user's imputs into three different arrays that pertain to the vaules. Finally, the program will generate a number of random product names/ideas, drawing values from the arrays.*/
//__________________________________Variables____________________________________
let adjectiveOne;
let nounIdeaOne;
let nounObjectOne;
let adjectiveTwo;
let nounIdeaTwo;
let nounObjectTwo;
//__________________________________Constants____________________________________


//Comment: Here I define the arrays we're going to use in the program to select values from when generating random product names/ideas, and I add some values into these arrays as well -------------------------------------------------//

const adjectives = ["Super","Mega","Awesome","Amazing","Turbo","Insane","Rockin'","Crazy"];

const nounIdeas = ["Strength","Constitution","Dexterity","Wisdom","Intelligence","Charisma","Morality","Righteousness"];

const nounObjects = ["Man","Woman","Tiger","Jet","Robot","Car","Park","Game"];




//___________________________________Main_______________________________________
    console.log("Hello!\n\nThis program will help you think of some ideas and/or product names!\n\nLet's enter a first set of values containing an adjective, a noun that is an idea, and\na noun that is an object.\n\n-----------------------------------------Set 1----------------------------------------\n");
    
adjectiveOne = prompt("Please enter your first adjective: ");

nounIdeaOne = prompt("\nPlease enter your first noun as an idea (meaning not a tangible thing): ");

nounObjectOne = prompt("\nPlease enter your first noun as an object (meaning a tangible thing): ");

        adjectives.push(adjectiveOne);
        nounIdeas.push(nounIdeaOne);
        nounObjects.push(nounObjectOne);
        
    console.log("\n--------------------------------------------------------------------------------------")
    
    
    console.log("\nNice!\n\nNow let's enter a second set of values with the same type of information, but different\nfrom the first!\n\n-----------------------------------------Set 2----------------------------------------\n");
    
adjectiveTwo = prompt("Please enter your second adjective: ");

nounIdeaTwo = prompt("\nPlease enter your second noun as an idea (meaning not a tangible thing): ");

nounObjectTwo = prompt("\nPlease enter your second noun as an object (meaning a tangible thing): ");    
    
        adjectives.push(adjectiveTwo);
        nounIdeas.push(nounIdeaTwo);
        nounObjects.push(nounObjectTwo);
        
        console.log("\n--------------------------------------------------------------------------------------")
        
        
        //Comment: Here I define a number of constants to use later which will generate the random combinations of product names/ideas ---------------------------//

const randomAdjectiveOne = adjectives[Math.floor(Math.random() * adjectives.length)];
const randomNounIdeaOne = nounIdeas[Math.floor(Math.random() * nounIdeas.length)];
const randomNounObjectOne = nounObjects[Math.floor(Math.random() * nounObjects.length)];
const randomAdjectiveTwo = adjectives[Math.floor(Math.random() * adjectives.length)];
const randomNounIdeaTwo = nounIdeas[Math.floor(Math.random() * nounIdeas.length)];
const randomNounObjectTwo = nounObjects[Math.floor(Math.random() * nounObjects.length)];
const randomAdjectiveThree = adjectives[Math.floor(Math.random() * adjectives.length)];
const randomNounIdeaThree = nounIdeas[Math.floor(Math.random() * nounIdeas.length)];
const randomNounObjectThree = nounObjects[Math.floor(Math.random() * nounObjects.length)];
const randomAdjectiveFour = adjectives[Math.floor(Math.random() * adjectives.length)];
const randomNounIdeaFour = nounIdeas[Math.floor(Math.random() * nounIdeas.length)];
const randomNounObjectFour = nounObjects[Math.floor(Math.random() * nounObjects.length)];
const randomAdjectiveFive = adjectives[Math.floor(Math.random() * adjectives.length)];
const randomNounIdeaFive = nounIdeas[Math.floor(Math.random() * nounIdeas.length)];
const randomNounObjectFive = nounObjects[Math.floor(Math.random() * nounObjects.length)];
        

        
        console.log("\nExcellent Job!\n\nHere are five random product names/ideas I generated that could also include the values\nyou entered:");

        console.log("\n\n#1: " + randomAdjectiveOne + " " + randomNounIdeaOne + " " + randomNounObjectOne);

        console.log("\n#2: " + randomAdjectiveTwo + " " + randomNounIdeaTwo + " " + randomNounObjectTwo);

        console.log("\n#3: " + randomAdjectiveThree + " " + randomNounIdeaThree + " " + randomNounObjectThree);

        console.log("\n#4: " + randomAdjectiveFour + " " + randomNounIdeaFour + " " + randomNounObjectFour);

        console.log("\n#5: " + randomAdjectiveFive + " " + randomNounIdeaFive + " " + randomNounObjectFive);