/* Name: Nicholas C. Hooper Webb
   Date: 10/13/2024
   Program name: CIS 156 Midterm
   Program Description: This program asks the user to imput a first and then second set of values consisting of an adjective, a noun that is an idea, and a noun that is an object. The program will then separate and add the user's imputs into three different arrays that pertain to the vaules. Finally, the program will generate a number of random product names/ideas, drawing values from the arrays. This program has been modified from its original version to include the demonstration of "for" and "while" loops.*/
   
//__________________________________Variables____________________________________

    //Comment: Because I am using the convenient structures of loops to re-write this program, I am able to reduce my variables to just 4; I declare 3 variables to define the values the user will enter, and one value named "index" that I will use later in the program for my "while" loop, and set it to = 0.
    
let adjectivePrompt;
let nounIdeaPrompt;
let nounObjectPrompt;
let index = 0
//__________________________________Constants____________________________________


//Comment: Here I define the arrays we're going to use in the program to select values from when generating random product names/ideas, and I add some values into these arrays as well. 

const adjectives = ["Super","Mega","Awesome","Amazing","Turbo","Insane","Rockin'","Crazy"];

const nounIdeas = ["Strength","Constitution","Dexterity","Wisdom","Intelligence","Charisma","Morality","Righteousness"];

const nounObjects = ["Man","Woman","Tiger","Jet","Robot","Car","Park","Game"];

//Comment: This time around I decided to declare a new array named "setOneOrTwo", and fill it with the strings I used to format the program based on whether the user had entered the first or second set of values. This makes it easier for me to use the "for" loop below by populating a console.log with one of two strings of text depending on the iteration of the loop.

const setOneOrTwo = ["Hello!\n\nThis program will help you think of some ideas and/or product names!\n\nLet's enter a first set of values containing an adjective, a noun that is an idea, and\na noun that is an object.\n\n-----------------------------------------Set 1----------------------------------------\n","\nNice!\n\nNow let's enter a second set of values with the same type of information, but different\nfrom the first!\n\n-----------------------------------------Set 2----------------------------------------\n"];


//___________________________________Main_______________________________________

    //Comment: I declare a "for" loop, using "i" for indexing, setting it to zero, making the parameters that it is less that 2, and incrementing the value of the variable by one each time it runs. Inside the loop I set values for the user imput variables I declared earlier to prompts, and then add them to the three arrays I made earlier.

for (let i = 0; i < 2; i++) {
    console.log(setOneOrTwo[i]);
    
adjectivePrompt = prompt("Please enter an adjective: ");

nounIdeaPrompt = prompt("\nPlease enter a noun as an idea (meaning not a tangible thing): ");

nounObjectPrompt = prompt("\nPlease enter a noun as an object (meaning a tangible thing): ");

        adjectives.push(adjectivePrompt);
        nounIdeas.push(nounIdeaPrompt);
        nounObjects.push(nounObjectPrompt);
        
    console.log("\n--------------------------------------------------------------------------------------");
}       
        
        
                console.log("\nExcellent Job!\n\nHere are five random product names/ideas I generated that could also include the values\nyou entered:\n\n");
        
        //Comment: Finally, I use a "while" loop to display 5 random combinations of the three arrays I defined. I use a series of nested "if" statements to format the program for visual purposes. Once the loop reaches 5 iterations, it and the program end.
        

while (index < 6) { 
    
    if (index == 1) {
        
        console.log("#1: " + adjectives[Math.floor(Math.random() * adjectives.length)] + " " + nounIdeas[Math.floor(Math.random() * nounIdeas.length)] + " " + nounObjects[Math.floor(Math.random() * nounObjects.length)]);
    }
    
    else if (index == 2) {
        
        console.log("#2: " + adjectives[Math.floor(Math.random() * adjectives.length)] + " " + nounIdeas[Math.floor(Math.random() * nounIdeas.length)] + " " + nounObjects[Math.floor(Math.random() * nounObjects.length)]);
    }
    
    else if (index == 3) {
        
        console.log("#3: " + adjectives[Math.floor(Math.random() * adjectives.length)] + " " + nounIdeas[Math.floor(Math.random() * nounIdeas.length)] + " " + nounObjects[Math.floor(Math.random() * nounObjects.length)]);
    }
    
    else if (index == 4) {
        
        console.log("#4: " + adjectives[Math.floor(Math.random() * adjectives.length)] + " " + nounIdeas[Math.floor(Math.random() * nounIdeas.length)] + " " + nounObjects[Math.floor(Math.random() * nounObjects.length)]);
    }
    
    else if (index == 5) {
        
        console.log("#5: " + adjectives[Math.floor(Math.random() * adjectives.length)] + " " + nounIdeas[Math.floor(Math.random() * nounIdeas.length)] + " " + nounObjects[Math.floor(Math.random() * nounObjects.length)]);
    }
        index++
}        