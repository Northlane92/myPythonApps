/*Name: Nicholas C. Hooper Webb

  Date: 11/13/2024
  
  Program Name: CIS156_Objects_II.js
  
  Program Description: This program will further demonstrate the use of objects by introducing a constructor function named car to easily create objects related to vehicle information, and retrieve data from them. */



//Variables---------------------------------------------------------------------
let userOption;
let newCarYear;
let newCarMake;
let newCarModel;


//Functions---------------------------------------------------------------------

function Car (car_year, car_make, car_model) {
    
        this.year = car_year,
        
        this.make = car_make,
        
        this.model = car_model;
}    
       
function pickACar () {
    
    while (userOption != 4) {
    
        userOption = prompt("\n\nPlease choose from the following options:\n\n1: View Car #1\n2: View Car #2\n3: View Car #3\n4: Exit Program\n\n> ");
    
    if (userOption == 1) {
        
                console.log("\n");
                console.log(car1);
                
            }
        
            else if (userOption == 2) {
                
                console.log("\n");
                console.log(car2);
            }
        
            else if (userOption == 3) {
                
                console.log("\n");
                console.log(car3);
            }    
            
            else {
                
                console.log("\nExiting Program...")
                process.exit(0);
            }
    
    }      
}

//Objects-----------------------------------------------------------------------

const car1 = new Car('1991', 'Ford', 'Mustang');
const car2 = new Car('2007', 'Dodge', 'Charger');

//Main-------------------------------------------------------------------------

console.log("Welcome to your virtual garage.");

newCarYear = prompt("\n\nEnter the information for your new vehicle:\n\nPlease enter the year of the vehicle: ");
    
    newCarMake = prompt("Please enter the make of the vehicle: ");
    
    newCarModel = prompt("Please enter the model of the vehicle: ");

    const car3 = new Car(newCarYear, newCarMake, newCarModel);


pickACar();