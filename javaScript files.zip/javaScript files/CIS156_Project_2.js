/* Name: Nicholas C. Hooper Webb
   Date: 09/18/2024
   Program name: CIS 156 Project 2
   Program Description:
        
Judd Benson runs a baked potato bar. Judd's head cashier, Dykell Sanders, keeps forgetting the price of each Fixin.
Judd wants a program that will tell his cashiers how much to add based on the chosen Fixin's.
A potato can have up to 3 Fixin's.
If the Fixin's add up to at least a dollar, the customer gets a 10% discount. 

All discounts are rounded down to the nearest cent.
Hint: Use the floor() method.
Example:  savings = Math.floor((cost * .10 *100))/100;

The Fixin's add the following costs to the sandwich:

yogurt - $1.00,
tomatoes - $0.50,
lettuce - $0.30,
skittles - $0.75

Write a program that will ask the cashier for each of the 3 Fixin's. It should calculate and display the total cost of toppings, the discount if applicable, and the total including discount.*/

//__________________________________Variables____________________________________
let fixinOne;
let fixinTwo;
let fixinThree;
let totalOne = 0;
let totalTwo = 0;
let totalThree = 0;
let discount;
let totWithDiscount;
//__________________________________Constants____________________________________
//____________________________________Main_______________________________________
    console.log("Hello!\nI am your Personal Potato Assistant!\nEnter up to 3 different potato fixin's and I will calculate the total cost.\n\nIf the total amount of the fixin's is more than $1.00, the customer will get a\n10% discount!\n\nPlease choose from the following options:\n\nLettuce\nTomato\nSkittles\nYogurt\nNone");
    
    

fixinOne = prompt("\nPlease enter the first fixin': ");
    
        switch(fixinOne) {
            case "Lettuce" :
                (totalOne) = 0.30.toFixed(2);
        break;
            case "lettuce" :
                (totalOne) = 0.30.toFixed(2);
        break;
            case "Tomato" :
                (totalOne) = 0.50.toFixed(2);
        break;
            case "tomato" :
                (totalOne) = 0.50.toFixed(2);        
        break;
            case "Skittles" :
                (totalOne) = 0.75.toFixed(2);
        break;
            case "skittles" :
                (totalOne) = 0.75.toFixed(2);
        break;
            case "Yogurt" :
                (totalOne) = 1.00.toFixed(2);
        break;
            case "yogurt" :
                (totalOne) = 1.00.toFixed(2);
        break;
            case "None" :
                (totalOne) = 0.00.toFixed(2);
        break;
            case "none" :
                (totalOne) = 0.00.toFixed(2);
        break;
            default :
                console.log("\nI'm sorry, but '" + (fixinOne) + "' is not one of our approved toppings.\nPlease restart the program and enter only one of the following options:\n\nLettuce\nTomato\nSkittles\nYogurt\nNone");
        }
        


fixinTwo = prompt("Please enter the second fixin': ");        
        
                switch(fixinTwo) {
            case "Lettuce" :
                (totalTwo) = (0.30 + Number(totalOne)).toFixed(2);
        break;
            case "lettuce" :
                (totalTwo) = (0.30 + Number(totalOne)).toFixed(2);
        break;
            case "Tomato" :
                (totalTwo) = (0.50 + Number(totalOne)).toFixed(2);
        break;
            case "tomato" :
                (totalTwo) = (0.50 + Number(totalOne)).toFixed(2);
        break;
            case "Skittles" :
                (totalTwo) = (0.75 + Number(totalOne)).toFixed(2);
        break;
            case "skittles" :
                (totalTwo) = (0.75 + Number(totalOne)).toFixed(2);
        break;
            case "Yogurt" :
                (totalTwo) = (1.00 + Number(totalOne)).toFixed(2);
        break;
            case "yogurt" :
                (totalTwo) = (1.00 + Number(totalOne)).toFixed(2);        
        break;
            case "None" :
                (totalTwo) = (0.00 + Number(totalOne));
        break;
            case "none" :
                (totalTwo) = (0.00 + Number(totalOne));
        break;
            default :
                console.log("\nI'm sorry, but '" + (fixinTwo) + "' is not one of our approved toppings.\nPlease restart the program and enter only one of the following options:\n\nLettuce\nTomato\nSkittles\nYogurt\nNone");
        }
        
        
        
fixinThree = prompt("Please enter the third fixin': ");     

        switch(fixinThree) {
            case "Lettuce" :
                (totalThree) = (0.30 + Number(totalTwo)).toFixed(2);
        break;
            case "lettuce" :
                (totalThree) = (0.30 + Number(totalTwo)).toFixed(2);
        break;
            case "Tomato" :
                (totalThree) = (0.50 + Number(totalTwo)).toFixed(2);
        break;
            case "tomato" :
                (totalThree) = (0.50 + Number(totalTwo)).toFixed(2);
        break;
            case "Skittles" :
                (totalThree) = (0.75 + Number(totalTwo)).toFixed(2);
        break;
            case "skittles" :
                (totalThree) = (0.75 + Number(totalTwo)).toFixed(2);
        break;
            case "Yogurt" :
                (totalThree) = (1.00 + Number(totalTwo)).toFixed(2);
        break;
            case "yogurt" :
                (totalThree) = (1.00 + Number(totalTwo)).toFixed(2);
        break;
            case "None" :
                (totalThree) = (0.00 + Number(totalTwo));
        break;
            case "none" :
                (totalThree) = (0.00 + Number(totalTwo));        
        break;
            default :
                console.log("\nI'm sorry, but '" + (fixinThree) + "' is not one of our approved toppings.\nPlease restart the program and enter only one of the following options:\n\nLettuce\nTomato\nSkittles\nYogurt\nNone");
        }
        
        

discount = (Number(totalThree) * 0.1).toFixed(2);
totWithDiscount = "$" + (Number(totalThree) - Number(discount)).toFixed(2);

        if (totalThree > 1.00) {
            console.log("\n\nThe customer earned a 10% discount!\nSavings: $" + discount + "\n\nThe customer's total is " + totWithDiscount + "");
        }
        
        else {
            console.log("\n\nThe customer's total is $" + totalThree.toFixed(2));
        }