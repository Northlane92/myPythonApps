/*Name: Nicholas C Hooper Webb
  Date: 09/08/2024
  Program Name: NHWU2-1.js
  Description: This is a simple program meant to generate a random number, and initiate a prompt for a user to guess that number. The console will then display a message concerning the accuracy of the user's guess and the actual number that was generated.*/
  
  //Variables______________________________________________________________________
  let cpuNum=Math.floor(Math.random() * (10 - 1) + 1);
  let userNum;
  //Constants______________________________________________________________________
  //Main___________________________________________________________________________
        console.log("Hello, there.\n");

        console.log("I want to play a game.\n");
        
       // console.log(cpuNum);
        
  userNum = prompt("Guess a number between 1 and 10: ");
        if (cpuNum == userNum) {
            console.log("\nCorrect.\nYou have won the game!")
        }
        
            else if (userNum > cpuNum) {
                console.log("\nIncorrect.\nYour number was too high.\nYou have lost the game >=3")
            }
            
            else if (userNum < cpuNum) {
                console.log("\nIncorrect.\nYour number was too low.\nYou have lost the game >=3")
            }
