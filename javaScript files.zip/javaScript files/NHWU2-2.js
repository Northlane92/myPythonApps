/*Name: Nicholas C Hooper Webb
  Date: 09/08/2024
  Program Name: NHWU2-2.js
  Description: This program asks the user for a time of the day in military time (hours 1 - 24) and generates different responses based on what time the user entered.*/
  
  //Variables______________________________________________________________________
  let hourOfDay;
  //Constants______________________________________________________________________
  //Main___________________________________________________________________________
  hourOfDay = Number(prompt("Please enter the hour of the day in military time (1-24): "));
        if (hourOfDay > 20 || hourOfDay < 6) {
            console.log("\nGood Day");
        }
            
            else if (hourOfDay >= 6 && hourOfDay < 12) {
                console.log("\nGood Morning");
            }
            
            else if (hourOfDay >= 12 && hourOfDay <= 20) {
                console.log("\nGood Afternoon")
            } 