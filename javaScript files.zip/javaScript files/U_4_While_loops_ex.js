/*Name: Nicholas C. Hooper Webb
Date: 10/06/2024
Program Name: U_4_While_loops_ex.js
Program Description: This is a simple program meant to demonstrate the function and ability of "while loops" in JavaScript by formatting one to give the user a list of options to pick from containing "greet" as option one, "Bid Farewell", as option two, and "End Program", as option 3. The program will run until the user picks option 3 - "End Program".*/

//Variables_____________________________________________________________________
    
        //Comment: Here I define a variable "userImput" which I will use later to have the option the user picks generate a response and assign further rules to it in the while loop.
        
let userInput = 0;

//Constants______________________________________________________________________

        //Comment: This array will contain the 3 different responses that can be printed based on ther user's choice.
        
const responses = ["Hello there!","I'll see you later!","Exiting Program..."];
   
//Main___________________________________________________________________________

console.log("Hello.\nThis is a 'while' loop test.\n");

        //Comment: I start a "while" loop statement by specifying the loop will end if the variable "userInput" is equal to three, because the third option is to exit the program. Next I nest a number of if/else if statements to make sure the correct response is generated based on the user's input. 

    while (userInput != 3) {
        
        userInput = prompt("Please enter 1, 2, or 3 to pick from the following options:\n\n1. Greet\n2. Bid Farewell\n3. End Program\n\nPick an option: ")
        
            if (userInput==1) {
                console.log("\n" + responses[0] + "\n")
            }
                else if (userInput==2) {
                    console.log("\n" + responses[1] + "\n")
                }
                else if (userInput==3) {
                    console.log("\n" + responses[2] + "\n")
                }
}
