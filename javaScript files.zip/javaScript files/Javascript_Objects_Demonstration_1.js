/* Name: Nicholas C. Hooper Webb
   Date: 11/03/2024
   Program Name: Javascript_Objects_Demonstration_1
   Program Description: This program is made to demonstrate the use of a Javascript ojbect, and show it's functionality in the console.*/
   
   //Constants---------------------------------------------------------------------
   
            //Comment: Here I define an object named "nickyBoy" (thats me!) and give it properties for my first name, middle initial, and last name, as well as my favorite color. Lastly, I nest a function called "greetMe" to combine these properties into a console.log greeting.
            
   const nickyBoy = {
       firstName: "Nicholas ",
       middleInitial: "C ",
       lastName: "Hooper Webb",
       favColor: "black",
       greetMe: function () {
           return 'Hello!\n\nMy name is ' +  (nickyBoy.firstName) + (nickyBoy.middleInitial) + (nickyBoy.lastName) + ', \nand my favorite color is ' + (nickyBoy.favColor) + '.';
       }
   };
   
   //Main-------------------------------------------------------------------------
   console.log (nickyBoy.greetMe());