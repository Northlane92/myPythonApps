/* Name: Nicholas C. Hooper Webb
   Date: 10/20/2024
   Program name: CIS 156 Functions Assignment
   Program Description: This program is a modification of my CIS 156 Midterm Project, and will demonstrate the use of functions showing the current time at the begginning and end of the program, and add a random number to each of the five products.*/
   
//__________________________________Variables____________________________________

let adjectivePrompt;
let nounIdeaPrompt;
let nounObjectPrompt;
let index = 0
//__________________________________Constants____________________________________


const adjectives = ["Super","Mega","Awesome","Amazing","Turbo","Insane","Rockin'","Crazy"];

const nounIdeas = ["Strength","Constitution","Dexterity","Wisdom","Intelligence","Charisma","Morality","Righteousness"];

const nounObjects = ["Man","Woman","Tiger","Jet","Robot","Car","Park","Game"];


const setOneOrTwo = ["Hello!\n\nThis program will help you think of some ideas and/or product names!\n\nLet's enter a first set of values containing an adjective, a noun that is an idea, and\na noun that is an object.\n\n-----------------------------------------Set 1----------------------------------------\n","\nNice!\n\nNow let's enter a second set of values with the same type of information, but different\nfrom the first!\n\n-----------------------------------------Set 2----------------------------------------\n"];

//________________________________Functions_____________________________________

    //Comment: Here I have added a function which creates a variable called "now" that fetches the current date from my computer, and adds a modification to the variable "now" by using .toLocaleTimeString to format the time retrieved from date to use a 12 hour time format, and I specified the time zone to be America/Chicago. Finally, I have the console print the current time within the function.

function time() {
    let now = new Date();
    let timeString = now.toLocaleTimeString('en-US', {
        timeZone: 'America/Chicago',
        hour: 'numeric',
        minute: 'numeric',
        hour12: true
    });
        console.log("Current Time: " + "\n" + timeString + "\n");
}

    //Comment: Here I create a function name randomNum that does just that, generates a random number between one and ten, and then prints it on the screen. I added "#" for an identifier of where it is used in the program

function randomNum() {
    let num = Math.floor(Math.random() * 10 + 1);
    console.log("#" + num);
}
//___________________________________Main_______________________________________


time();

for (let i = 0; i < 2; i++) {
    console.log(setOneOrTwo[i]);
    
adjectivePrompt = prompt("Please enter an adjective: ");

nounIdeaPrompt = prompt("\nPlease enter a noun as an idea (meaning not a tangible thing): ");

nounObjectPrompt = prompt("\nPlease enter a noun as an object (meaning a tangible thing): ");

        adjectives.push(adjectivePrompt);
        nounIdeas.push(nounIdeaPrompt);
        nounObjects.push(nounObjectPrompt);
        
    console.log("\n--------------------------------------------------------------------------------------");
}       
        
        
                console.log("\nExcellent Job!\n\nHere are five random product names/ideas I generated that could also include the values\nyou entered:\n\n");
        


while (index < 6) { 
    
    if (index == 1) {
        
        randomNum()
        console.log(adjectives[Math.floor(Math.random() * adjectives.length)] + " " + nounIdeas[Math.floor(Math.random() * nounIdeas.length)] + " " + nounObjects[Math.floor(Math.random() * nounObjects.length)]);
    }
    
    else if (index == 2) {
        
        randomNum()
        console.log(adjectives[Math.floor(Math.random() * adjectives.length)] + " " + nounIdeas[Math.floor(Math.random() * nounIdeas.length)] + " " + nounObjects[Math.floor(Math.random() * nounObjects.length)]);
    }
    
    else if (index == 3) {
        
        randomNum()
        console.log(adjectives[Math.floor(Math.random() * adjectives.length)] + " " + nounIdeas[Math.floor(Math.random() * nounIdeas.length)] + " " + nounObjects[Math.floor(Math.random() * nounObjects.length)]);
    }
    
    else if (index == 4) {
    
        randomNum()
        console.log(adjectives[Math.floor(Math.random() * adjectives.length)] + " " + nounIdeas[Math.floor(Math.random() * nounIdeas.length)] + " " + nounObjects[Math.floor(Math.random() * nounObjects.length)]);
    }
    
    else if (index == 5) {
        
        randomNum()
        console.log(adjectives[Math.floor(Math.random() * adjectives.length)] + " " + nounIdeas[Math.floor(Math.random() * nounIdeas.length)] + " " + nounObjects[Math.floor(Math.random() * nounObjects.length)]);
    }
        index++
}

console.log("\n");
time();