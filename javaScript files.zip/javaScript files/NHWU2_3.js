/*Name: Nicholas C. Hooper Webb
  Date: 09/08/2024
  Program Name: NHWU2-3.js
  Description: This program prompts the user to pick from a list of secondary colors and will generate which primary colors to mix to get the users    color.*/
  //Variables_______________________________________________________________________
 let userColor;
 //Constants_______________________________________________________________________
 //Main____________________________________________________________________________
    console.log("Pick a secondary color to learn which primary colors to mix!\n");
    
    userColor = prompt("Enter one of the following colors:\nOrange, Green, Purple, White, Black > ");
    
        if (userColor == "Orange" || userColor == "orange") {
            console.log("\nMix red and yellow to get orange!")
        }
    
        else if (userColor == "Green" || userColor == "green") {
            console.log("\nMix blue and yellow to get green!")
        }
        
        else if (userColor == "Purple" || userColor == "purple") {
            console.log("\nMix red and blue to get purple!")
        }
        
        else if (userColor == "White" || userColor == "white") {
            console.log("\nWhite is the absence of color. Don't add any colors to get white!")
        }
        
        else if (userColor == "Black" || userColor == "black") {
            console.log("\nMix all the colors to get black!")
        }
        
            else {
                console.log("\nI'm sorry, that is not one of the listed colors.\nPlease restart the program and try again.") 
            }