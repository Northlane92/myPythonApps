#Name: Nicholas C. Hooper Webb
#Date: 02/14/2025
#Program Name: bug_collector_assignment.py
#Program Description: This program uses a loop and a nested if statement to #calculate the total of how many bugs a user collects in 7 days.

#This is just a print with some formatting that introduces the user to the app
print("|||||||||||||||||||||||||||||||||| BUG COUNTER V3.2 ||||||||||||||||||||||||||||||||||||\n-----------------------------------------------------------------------------------------\n\nWelcome to Bug Counter!\n\nThis program will help you count all the bugs you collected in a 7 day period!\n\n")

#This list is left empty to be later filled with the numbers representing the #amount of bugs a user collects on a certain day
bugsCollected = []

#This loops an input asking the user to enter an amount of bugs collected for the #day which is represented by the variable "day", and adds the user's input to #the list "bugsCollected"
for day in range(1,8):
    howManyBugs = int(input(f"\nPlease enter the amount of bugs you collected on day {day}: "))
    bugsCollected.append(howManyBugs)
    
    #This nested if statement activates when the loop hits its 7th iteration and #prints a message displaying the total amount of bugs collected, and then #ends the program
    if day == 7:
        print(f"\n\n\nYou collected a total of {sum(bugsCollected)} bugs in {day} days!")
        break