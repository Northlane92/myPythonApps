#Name: Nicholas C. Hooper Webb
#Date: 01/26/2025
#Program Name: temp_convrsn_assignment.py
#Program Description: This program will take a user's input as a temperature measured in Farenheit, and convert then display it in Celsius.

#lets the user know what the program is for and to only use numbers as imputs
print ("Hello.\n\nThis program was made to help take a temperature you enter in Farenheit, and covert it\nto Celsius.\n\nPlease only use numbers for your answer, or the program will run into an error and you\nwill have to re-start.")

#variable is an input asking the user to enter a temp in Farenheit. Converts str to float
userFarenTemp = float(input("\n\nPlease enter a temperature in Farenheit: "))

#variable applies the correct formula for converting user's temp to Celsius
userCelsConvrsn = (userFarenTemp - 32) * (5/9)

#variable takes the result of the conversion and rounds it to two decimal places
userCelsTemp = round(userCelsConvrsn, 2)

#shows the user their original temp, what it is in Celsius, and "exits" the program
print (f"\n\n{userFarenTemp} degrees Farenheit is {userCelsTemp} degrees Celsius.\n\nThank you for using this program.\n\n\nExiting...")