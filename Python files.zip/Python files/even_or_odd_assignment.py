#Name: Nicholas C. Hooper Webb
#Date: 01/26/2025
#Program Name: even_or_odd_assignment.py
#Program Descripton: This program asks the user to enter a number, checks to see whether it is even or odd, and then displays that check to the user in a message.


#introduces program, is kind of funny (I hope)
print ("Hello, there!\n\nI am your handy-dandy number checker!\n\nEnter a number and I will tell you if it is even or odd!")

#variable has the user input a number and converts it to a float
userNumber = float(input("\n\nPlease enter a number: "))

#if the num the user entered can be divided by two until it becomes 0, it prints "the number you entered is even", otherwise it prints "The number you entered is odd"
if userNumber % 2 == 0: 
    
    print ("\n\nThe number you entered is even!")
    
else:
    
    print ("\n\nThe number you entered is odd!")