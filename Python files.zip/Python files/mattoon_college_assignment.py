#Name: Nicholas C. Hooper Webb
#Date: 02/14/2025
#Program Name: mattoon_college_assignment.py
#Program Description: This program uses a "for" loop to calculate what a 2% #increase in Lake Land College's base tuition of $6000 would look like over a 5 #year period.

#This variable sets the base amount of Lake Land College's tuition
baseTuition = 6000

#This variable sets what the base tuition is expected to increase by
tuitionIncrease = 0.02

#This print gives the output some formatting
print("Year      |    Projected Tuition\n--------------------------------")

#This loop names an indexer "year" and sets the range to start at 1 and stop at 5. #I use "+=" to add the base tuition to it's 2% increase every year, and create #another variable to limit the output to two decimal places. Finally, the loop #prints the output for every iteration
for year in range(1, 6):
    baseTuition += (baseTuition * tuitionIncrease)
    roundTuition = round(baseTuition, 2)
    print(f"{year}         |     ${roundTuition}")