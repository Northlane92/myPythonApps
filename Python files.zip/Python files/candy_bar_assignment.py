#Name: Nicholas C. Hooper Webb
#Date: 02/14/2025
#Program Name: candy_bar_assignment.py
#Program Description: This program uses a list, some simple math, and a "for" loop #to show how many "chocolate bars" a machine can produce given an amount of #time in minutes.

#This variable sets the amount of bars the machine can put out per minute
chocoPerMinute = 80

#This list defines the times set by the assignment: 10, 15, 20, 25, and 30 minutes
minutes = [10, 15, 20, 25, 30]

#This print gives the output some formatting
print("MINUTES    |    CHOCOLATE BARS\n------------------------------")

#This loop names an indexer "time" to loop through the items in the list "minutes"
#, then names a variable "totalChocoBars" which is the result of multiplying the ba
#se bars per minute, by the amount of minutes, which is represented by "time", fina
#lly, it prints out the time and what the amount of chocolate bars produced for tha
#t time would be
for time in minutes:
    totalChocoBars = chocoPerMinute * time
    print(f"{time}         |     {totalChocoBars}")